package com.radhikacab.faremeter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.location.Geocoder
import android.location.Location
import com.google.android.gms.tasks.CancellationTokenSource
import android.widget.EditText
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.round

class MainActivity : ComponentActivity() {
    private val farePerKm = 25.0
    private val prefs by lazy { getSharedPreferences("trip_state", MODE_PRIVATE) }
    private lateinit var statusText: TextView
    private lateinit var distanceText: TextView
    private lateinit var fareText: TextView
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var pdfButton: Button
    private var tracking = false
    private var totalMeters = 0.0
    private var startTime = ""
    private var endTime = ""
    private var paymentScreen = false
    private var driverName = ""
    private var startLocation = ""
    private var endLocation = ""
    private val createPdfCode = 202

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) requestNotificationPermission()
        else Toast.makeText(this, "अचूक GPS साठी Precise Location परवानगी द्या.", Toast.LENGTH_LONG).show()
    }
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val tripReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            totalMeters = intent.getDoubleExtra("meters", totalMeters)
            tracking = prefs.getBoolean("tracking", false)
            if (intent.action == TripLocationService.ACTION_STOPPED) {
                endTime = now()
                statusText.text = "प्रवास पूर्ण • रोख रक्कम जमा करा"
            } else statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
            refreshNumbers()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreTripState()
        buildScreen()
        if (!hasFineLocationPermission()) requestLocationPermission() else requestNotificationPermission()
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(TripLocationService.ACTION_UPDATE)
            addAction(TripLocationService.ACTION_STOPPED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(tripReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(tripReceiver, filter)
        restoreTripState()
    }

    override fun onStop() {
        try { unregisterReceiver(tripReceiver) } catch (_: IllegalArgumentException) { }
        super.onStop()
    }

    private fun restoreTripState() {
        tracking = prefs.getBoolean("tracking", false)
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        startTime = prefs.getString("start_time", "") ?: ""
        endTime = prefs.getString("end_time", "") ?: ""
        driverName = prefs.getString("driver_name", "Prafulla Kale") ?: "Prafulla Kale"
        startLocation = prefs.getString("start_location", "") ?: ""
        endLocation = prefs.getString("end_location", "") ?: ""
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
    private fun params(w: Int = -1, h: Int = -2, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, if (h == -2) -2 else dp(h)).apply { bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(0xFFEAF0F7.toInt())
    }

    private fun styledButton(title: String, color: Int): Button = Button(this).apply {
        text = title; textSize = 16f; isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(color)
    }

    private fun buildScreen() {
        paymentScreen = false
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(0xFFF4F6F8.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(14), dp(18), dp(14), dp(18))
            setBackgroundColor(0xFF075B35.toInt())
        }
        header.addView(label("🚕  Radhika Cab", 24f, -1, true))
        header.addView(label("GPS Fare Meter", 14f, 0xFFE1F3E8.toInt()))
        header.addView(label(if (tracking) "● GPS ON  •  प्रवास सुरू आहे" else "ड्रायव्हर : $driverName", 14f, 0xFFFFFFFF.toInt(), true))
        root.addView(header, params(bottom = 14))

        val fareCard = card()
        fareCard.addView(label("भाडे दर  •  ₹25 प्रति किलोमीटर", 19f, 0xFF123B2A.toInt(), true))
        root.addView(fareCard, params(bottom = 12))

        val mapCard = card()
        mapCard.setBackgroundColor(0xFFE8F0F7.toInt())
        mapCard.addView(label("📍  GPS ROUTE TRACKING", 16f, 0xFF174A75.toInt(), true))
        mapCard.addView(label(if (tracking) "● GPS सिग्नल सक्रिय  •  अंतर मोजले जात आहे" else "START दाबल्यानंतर GPS अंतर मोजले जाईल", 13f, 0xFF40566A.toInt()))
        root.addView(mapCard, params(bottom = 12))

        val stats = card()
        stats.orientation = LinearLayout.HORIZONTAL
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        left.addView(label("प्रवासाचे अंतर", 14f, 0xFF526171.toInt()))
        distanceText = label("0.00 km", 25f, 0xFF101D2D.toInt(), true)
        left.addView(distanceText)
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        right.addView(label("एकूण भाडे", 14f, 0xFF526171.toInt()))
        fareText = label("₹0.00", 25f, 0xFF087A43.toInt(), true)
        right.addView(fareText)
        stats.addView(left); stats.addView(right)
        root.addView(stats, params(bottom = 12))

        val timeCard = card()
        timeCard.addView(label("◷  प्रवास सुरू वेळ", 14f, 0xFF34465A.toInt(), true))
        timeCard.addView(label(if (startTime.isBlank()) "—" else startTime, 15f, 0xFF182536.toInt()))
        timeCard.addView(label("⌖  सुरुवातीचे ठिकाण", 14f, 0xFF34465A.toInt(), true))
        timeCard.addView(label(startLocation.ifBlank { "GPS लोकेशन मिळत आहे / सेट करा" }, 14f, 0xFF182536.toInt()))
        timeCard.addView(styledButton("✎  Start Location Edit", 0xFF526171.toInt()).apply {
            setOnClickListener { editLocation(true) }
        }, params(h = 46, bottom = 8))
        timeCard.addView(label("🏁  शेवटचे ठिकाण", 14f, 0xFF34465A.toInt(), true))
        timeCard.addView(label(endLocation.ifBlank { "प्रवास संपल्यावर GPS लोकेशन नोंदेल" }, 14f, 0xFF182536.toInt()))
        timeCard.addView(styledButton("✎  End Location Edit", 0xFF526171.toInt()).apply {
            setOnClickListener { editLocation(false) }
        }, params(h = 46))
        root.addView(timeCard, params(bottom = 14))

        startButton = styledButton("▶  START  •  प्रवास सुरू करा", 0xFF07833F.toInt()).apply { setOnClickListener { startTrip() } }
        endButton = styledButton("■  END  •  प्रवास समाप्त करा", 0xFFD92323.toInt()).apply { setOnClickListener { endTrip() } }
        root.addView(startButton, params(h = 58, bottom = 10))
        root.addView(endButton, params(h = 58, bottom = 12))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val history = styledButton("☷  प्रवास नोंदी", 0xFF236DB5.toInt()).apply { setOnClickListener { showHistory() } }
        pdfButton = styledButton("PDF बिल", 0xFFB52A2A.toInt()).apply { setOnClickListener { createPdf() } }
        val settings = styledButton("⚙  सेटिंग", 0xFF526171.toInt()).apply { setOnClickListener { showSettings() } }
        actions.addView(history, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(4) })
        actions.addView(pdfButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        actions.addView(settings, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(4) })
        root.addView(actions, params(bottom = 12))
        statusText = label(if (tracking) "प्रवास सुरू आहे • Background GPS चालू" else "प्रवास सुरू करण्यासाठी START दाबा", 13f, 0xFF687568.toInt())
        root.addView(statusText, params())
        scroll.addView(root)
        setContentView(scroll)
        refreshNumbers()
    }

    private fun hasFineLocationPermission() =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationPermission() {
        locationPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun startTrip() {
        if (!hasFineLocationPermission()) { requestLocationPermission(); return }
        if (tracking) return
        totalMeters = 0.0; startTime = now(); endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", true)
            .putString("start_time", startTime).putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        captureLocation(true, true)
        val serviceIntent = Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, serviceIntent) else startService(serviceIntent)
            tracking = true
            buildScreen()
        } catch (e: Exception) {
            prefs.edit().putBoolean("tracking", false).commit()
            tracking = false
            Toast.makeText(this, "GPS Service सुरू झाली नाही: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            buildScreen()
        }
    }

    private fun endTrip() {
        if (!tracking) return
        startService(Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_STOP))
        tracking = false
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        endTime = now()
        prefs.edit().putBoolean("tracking", false).putString("end_time", endTime).commit()
        captureLocation(false)
        showPaymentScreen()
    }

    private fun roundedKm() = round((totalMeters / 1000.0) * 100.0) / 100.0
    private fun fareAmount() = round(roundedKm() * farePerKm * 100.0) / 100.0

    private fun showPaymentScreen() {
        paymentScreen = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(18), dp(24), dp(18), dp(24)); setBackgroundColor(0xFF078A3D.toInt())
        }
        root.addView(label("🚕  Radhika Cab", 23f, -1, true), params(bottom = 8))
        root.addView(label(String.format(Locale.US, "₹ %.2f", fareAmount()), 48f, -1, true), params(bottom = 14))
        root.addView(label("ग्राहकाकडून रोख रक्कम घ्या", 20f, -1, true))
        root.addView(label("PAY IN CASH", 22f, -1, true), params(bottom = 18))
        val detail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(0xFF2BA85B.toInt())
        }
        detail.addView(label("📍  एकूण अंतर : ${String.format(Locale.US, "%.2f", roundedKm())} km", 17f, -1, true))
        detail.addView(label("₹  दर : ₹25 / km", 17f, -1, true))
        detail.addView(label("ड्रायव्हर : $driverName", 16f, -1, true))
        detail.addView(label("सुरुवात : ${startLocation.ifBlank { "माहिती उपलब्ध नाही" }}", 14f, -1))
        detail.addView(label("शेवट : ${endLocation.ifBlank { "माहिती उपलब्ध नाही" }}", 14f, -1))
        root.addView(detail, params(bottom = 18))
        root.addView(styledButton("▣  बिल डाउनलोड (PDF)", 0xFFFFFFFF.toInt()).apply {
            setTextColor(0xFF173B2A.toInt()); setOnClickListener { createPdf() }
        }, params(h = 58, bottom = 12))
        root.addView(styledButton("✓  CASH COLLECTED", 0xFF0878D1.toInt()).apply {
            textSize = 18f
            setOnClickListener { saveTripAndReturn() }
        }, params(h = 60))
        setContentView(root)
    }

    private fun saveTripAndReturn() {
        val history = prefs.getString("history", "") ?: ""
        val record = "${now()} | ${String.format(Locale.US, "%.2f", roundedKm())} km | ₹${String.format(Locale.US, "%.2f", fareAmount())}"
        prefs.edit().putString("history", if (history.isBlank()) record else "$record\n$history").commit()
        totalMeters = 0.0; tracking = false; startTime = ""; endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", false)
            .putString("start_time", "").putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        buildScreen()
        AlertDialog.Builder(this).setTitle("✓  धन्यवाद!")
            .setMessage("रोख रक्कम जमा झाली आहे.")
            .setPositiveButton("OK", null).show()
    }

    private fun showHistory() {
        val history = prefs.getString("history", "") ?: ""
        AlertDialog.Builder(this).setTitle("प्रवास नोंदी (History)")
            .setMessage(if (history.isBlank()) "अजून कोणताही पूर्ण प्रवास नाही." else history.replace("\n", "\n"))
            .setPositiveButton("OK", null).show()
    }

    private fun showSettings() {
        val input = EditText(this).apply {
            setSingleLine(true); setText(driverName); hint = "ड्रायव्हरचे नाव"
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("ड्रायव्हरचे नाव बदला")
            .setMessage("प्रत्येक ड्रायव्हरसाठी नाव येथे Edit करा.")
            .setView(input)
            .setPositiveButton("सेव्ह करा") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    driverName = name
                    prefs.edit().putString("driver_name", name).apply()
                    buildScreen()
                } else Toast.makeText(this, "ड्रायव्हरचे नाव रिकामे ठेवू नका.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun editLocation(isStart: Boolean) {
        val input = EditText(this).apply {
            setText(if (isStart) startLocation else endLocation)
            hint = "ठिकाण / पत्ता लिहा"; minLines = 2
        }
        AlertDialog.Builder(this)
            .setTitle(if (isStart) "Start Location बदला" else "End Location बदला")
            .setView(input)
            .setPositiveButton("सेव्ह करा") { _, _ ->
                val value = input.text.toString().trim()
                if (isStart) startLocation = value else endLocation = value
                prefs.edit().putString(if (isStart) "start_location" else "end_location", value).apply()
                buildScreen()
            }
            .setNeutralButton("Automatic GPS") { _, _ -> captureLocation(isStart, true) }
            .setNegativeButton("रद्द", null).show()
    }

    @Suppress("MissingPermission")
    private fun captureLocation(isStart: Boolean, redraw: Boolean = false) {
        if (!hasFineLocationPermission()) return
        val client = LocationServices.getFusedLocationProviderClient(this)
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                if (loc == null) {
                    client.lastLocation.addOnSuccessListener { last ->
                        if (last != null) saveLocationAddress(last, isStart, redraw)
                        else Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
                    }
                } else saveLocationAddress(loc, isStart, redraw)
            }
            .addOnFailureListener {
                Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
            }
    }

    @Suppress("DEPRECATION")
    private fun saveLocationAddress(location: Location, isStart: Boolean, redraw: Boolean) {
        try {
            val geocoder = Geocoder(this, Locale("mr", "IN"))
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val address = addresses?.firstOrNull()?.getAddressLine(0)
                ?: String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = address else endLocation = address
            prefs.edit().putString(if (isStart) "start_location" else "end_location", address).apply()
        } catch (_: Exception) {
            val coordinates = String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = coordinates else endLocation = coordinates
            prefs.edit().putString(if (isStart) "start_location" else "end_location", coordinates).apply()
        }
        if (paymentScreen) showPaymentScreen() else if (redraw) buildScreen()
    }

    private fun refreshNumbers() {
        val km = roundedKm()
        if (::distanceText.isInitialized) distanceText.text = String.format(Locale.US, "%.2f km", km)
        if (::fareText.isInitialized) fareText.text = String.format(Locale.US, "₹%.2f", fareAmount())
        if (::startButton.isInitialized) {
            startButton.isEnabled = !tracking
            startButton.alpha = if (tracking) .45f else 1f
            endButton.isEnabled = tracking
            endButton.alpha = if (tracking) 1f else .45f
            pdfButton.isEnabled = !tracking && endTime.isNotBlank()
            pdfButton.alpha = if (pdfButton.isEnabled) 1f else .55f
        }
    }

    private fun now() = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale("en", "IN")).format(Date())

    private fun createPdf() {
        if (endTime.isBlank()) {
            Toast.makeText(this, "प्रवास संपल्यानंतर PDF बिल डाउनलोड करा.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "RadhikaCab_Bill_${System.currentTimeMillis()}.pdf")
        }
        startActivityForResult(intent, createPdfCode)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createPdfCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { writePdf(it) }
                Toast.makeText(this, "PDF बिल सेव झाले.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "PDF सेव करताना त्रुटी: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writePdf(out: OutputStream) {
        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 20f }
        paint.textSize = 28f; paint.isFakeBoldText = true; canvas.drawText("RADHIKA CAB", 50f, 70f, paint)
        paint.textSize = 16f; paint.isFakeBoldText = false; canvas.drawText("GPS TRIP BILL", 50f, 105f, paint)
        canvas.drawLine(50f, 125f, 545f, 125f, paint)
        paint.textSize = 18f
        val lines = listOf(
            "Driver: $driverName", "Trip date: $startTime", "Trip ended: $endTime",
            "Start location: ${startLocation.ifBlank { "Not available" }}",
            "End location: ${endLocation.ifBlank { "Not available" }}",
            String.format(Locale.US, "Distance: %.2f km", roundedKm()),
            "Rate: Rs. 25.00 per km",
            String.format(Locale.US, "TOTAL FARE: Rs. %.2f", fareAmount())
        )
        var y = 180f
        for (line in lines) {
            var remaining = line
            while (remaining.isNotEmpty()) {
                val count = paint.breakText(remaining, true, 490f, null)
                if (count <= 0) break
                canvas.drawText(remaining.substring(0, count), 50f, y, paint)
                remaining = remaining.substring(count).trimStart()
                y += 28f
            }
            y += 14f
        }
        paint.textSize = 12f
        canvas.drawText("Distance is calculated using device GPS. Actual accuracy may vary.", 50f, minOf(y + 20f, 800f), paint)
        pdf.finishPage(page); pdf.writeTo(out); pdf.close()
    }
}
