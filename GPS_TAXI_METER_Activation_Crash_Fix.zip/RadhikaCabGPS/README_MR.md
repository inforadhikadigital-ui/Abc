# Radhika Cab GPS Fare Meter – Updated

- भाडे दर: ₹25 प्रति km
- START / END प्रवास नियंत्रण
- GPS Foreground Service द्वारे Background tracking
- पेमेंट स्क्रीन: PAY IN CASH
- PDF बिल डाउनलोड
- CASH COLLECTED नंतर धन्यवाद संदेश व मुख्य स्क्रीन
- प्रवास History व Settings

## Build
Android project root मधून `gradle clean assembleDebug` चालवा.
APK: `app/build/outputs/apk/debug/app-debug.apk`

## महत्त्वाच्या सूचना
- पहिल्यांदा वापरताना Precise Location आणि Notifications परवानगी द्या.
- Android Settings मध्ये Radhika Cab साठी Battery usage `Unrestricted`/`Allow background activity` उपलब्ध असल्यास निवडा.
- GPS अंतराची अचूकता फोन, सिग्नल आणि GPS परिस्थितीवर अवलंबून असते. प्रत्यक्ष प्रवासात भाडे तपासूनच वापरा.
- या आवृत्तीत नकाशा पॅनल हे GPS स्थिती दाखवणारे डिझाइन पॅनल आहे; Google Maps नकाशा API जोडलेला नाही.


## या अपडेटमधील नवीन सुविधा
- Settings मधून ड्रायव्हरचे नाव बदलता येते; नाव फोनमध्ये सेव्ह राहते.
- START करताना सुरुवातीचे GPS ठिकाण आपोआप मिळवण्याचा प्रयत्न होतो.
- END करताना शेवटचे GPS ठिकाण आपोआप मिळवण्याचा प्रयत्न होतो.
- Start Location आणि End Location साठी Manual Edit आणि Automatic GPS पर्याय.
- Payment स्क्रीन आणि PDF बिलात ड्रायव्हरचे नाव, सुरुवात व शेवटचे ठिकाण.
- GPS पत्ता मिळाला नाही किंवा Geocoder उपलब्ध नसेल तर अक्षांश/रेखांश दाखवले जातात; Manual Edit वापरता येतो.

## Build बाबत
या ZIP मध्ये Gradle Wrapper executable/JAR समाविष्ट नाही. त्यामुळे Android Studio/Gradle असलेल्या संगणकावर प्रोजेक्ट उघडून Gradle Sync करून APK build करावा. या वातावरणात APK build किंवा प्रत्यक्ष Android GPS चाचणी केलेली नाही.


## GPS TAXI METER + Activation API अपडेट
- App नाव: GPS TAXI METER
- Driver Name सुरुवातीला रिकामे; Settings मधून लिहिता/बदलता/रिकामे करता येते.
- पहिल्यांदा App उघडल्यावर Activation Screen दिसते.
- Cloudflare Worker URL ला HTTPS POST JSON पाठवले जाते: `{"code":"...","deviceId":"ANDROID_ID"}`.
- HTTP 403 आल्यास दुसऱ्या डिव्हाइसवरील वापर नाकारला जातो. यशस्वी 2xx response नंतर स्थानिक activation flag सेव्ह होतो.

**महत्त्वाचे API गृहितक:** Worker `POST` JSON मध्ये `code` आणि `deviceId` स्वीकारतो आणि यशासाठी HTTP 2xx, दुसऱ्या डिव्हाइससाठी HTTP 403 देतो, असे गृहित धरले आहे. आधीच्या Worker चा अचूक contract स्वतंत्रपणे तपासलेला नाही; त्यामुळे प्रत्यक्ष मोबाईलवर Activation चाचणी आवश्यक आहे. Worker वेगळे field names किंवा response status वापरत असल्यास API request/response जुळवावे लागेल.

## सुरक्षा टीप
Android ID वापरला आहे. Factory reset, काही Android profile/OS परिस्थिती किंवा app-signing बदलांमुळे ID बदलू शकतो. Server-side binding हे अंतिम नियंत्रण आहे. APK प्रत्यक्ष build व device test या वातावरणात केलेले नाहीत.

\n## Background GPS सुधारणा (2026-11)\n
- High accuracy location request आता 1 सेकंदाच्या interval ने मागवली जाते.
- 25 मीटरपेक्षा कमी/समान accuracy असलेले fixesच वापरले जातात.
- GPS drift कमी करण्यासाठी accuracy-आधारित noise threshold लावला आहे.
- अशक्य वेगाने होणारे GPS jumps वगळले जातात.
- Trip सुरू असताना foreground service मध्ये partial wake lock वापरला जातो.
- Android Settings मध्ये GPS TAXI METER साठी Location = Allow while using / Precise ON,
  Battery = Unrestricted, आणि Battery Saver OFF ठेवा.
\nटीप: GPS ची अचूकता इमारती, बोगदे, खराब हवामान, फोनचे GPS हार्डवेअर आणि नेटवर्कवर अवलंबून असते.
ही source update आहे; प्रत्यक्ष फोनवर चाचणी करूनच मोजमापाची अचूकता निश्चित करा.


## Driver Utility vNext additions
- Driver-specific profile fields (vehicle number/type/fuel/service KM) are stored locally on each phone.
- Document expiry dates for Insurance, PUC, Fitness, Driving Licence and Permit. Dates use YYYY-MM-DD. Expired-document WhatsApp message opens to 9710409696 (India +91) with a prefilled editable message; user must tap Send.
- Daily income is accumulated from completed trips; expenses can be added manually. Values are local to this device and resettable.
- Trip history remains locally stored; PDF bill branding changed to GPS TAXI METER.
- Driver Safety stores an emergency contact and opens the phone dialer (does not auto-call).
- Language selector stores Marathi/Hindi/English choice; not all existing screens are fully translated in this build.
- Core app records are stored locally and basic meter/history functions work offline; GPS requires location services.
- No Radhika Cab brand text is used in the driver-facing bill/notification.


## Driver Profile Update (added)
- Dashboard profile card and dedicated Driver Profile tile open the editable profile screen.
- Editable fields: Driver Name, Mobile Number, Vehicle Number, Vehicle Type, Vehicle Model, Emergency Contact.
- Profile photo can be selected from the phone gallery.
- Profile values and photo URI are saved locally using SharedPreferences.
- Save / Update returns to the dashboard.
- This is source-code integration only; an APK build and real-device test are still required.


## Device ID स्थिर ठेवण्यासाठी महत्त्वाची नोंद

अॅप Device ID साठी Android `Settings.Secure.ANDROID_ID` वापरते. Uninstall/Reinstall नंतरही तोच ID मिळण्यासाठी प्रत्येक APK मध्ये समान `applicationId` (`com.radhikacab.faremeter`) आणि समान release signing key वापरणे आवश्यक आहे. Package name किंवा signing key बदलल्यास Android वेगळा ID देऊ शकतो.
