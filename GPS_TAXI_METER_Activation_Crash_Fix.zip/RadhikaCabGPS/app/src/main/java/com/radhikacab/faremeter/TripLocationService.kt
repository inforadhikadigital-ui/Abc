package com.radhikacab.faremeter

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*

class TripLocationService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private val prefs by lazy { getSharedPreferences("trip_state", MODE_PRIVATE) }
    private val channelId = "radhika_trip_tracking"
    private var wakeLock: PowerManager.WakeLock? = null

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            var meters = prefs.getFloat("total_meters", 0f).toDouble()
            var last = lastLocation
            for (loc in result.locations) {
                // Ignore weak fixes. A taxi meter should prefer a small under-count
                // over adding large GPS jumps while the vehicle is stationary.
                if (!loc.hasAccuracy() || loc.accuracy > 25f) continue

                if (last != null) {
                    val delta = last.distanceTo(loc).toDouble()
                    val seconds = ((loc.time - last.time).coerceAtLeast(1L)) / 1000.0
                    val allowedNoise = maxOf(3.0, ((last.accuracy + loc.accuracy) * 0.35).toDouble())
                    val speed = delta / seconds

                    // Reject GPS drift and implausible jumps.
                    if (delta > allowedNoise && speed <= 45.0) meters += delta
                }
                last = loc
            }
            lastLocation = last
            prefs.edit().putFloat("total_meters", meters.toFloat()).apply()
            sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("meters", meters))
            updateNotification(meters)
        }
    }
    private var lastLocation: Location? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopTracking(); return START_NOT_STICKY }
            else -> startTracking()
        }
        return START_STICKY
    }

    private fun startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        val notification = buildNotification(0.0)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        prefs.edit().putBoolean("tracking", true).commit()

        // Keep the CPU awake while the foreground location service is measuring a trip.
        try {
            val power = getSystemService(POWER_SERVICE) as PowerManager
            if (wakeLock?.isHeld != true) {
                wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:TripGps")
                wakeLock?.acquire(10 * 60 * 60 * 1000L) // safety timeout: 10 hours
            }
        } catch (_: Exception) { }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(1000L)
            .setMinUpdateDistanceMeters(3f)
            .setMaxUpdateDelayMillis(0L)
            .setWaitForAccurateLocation(true)
            .build()
        try {
            fused.requestLocationUpdates(request, callback, Looper.getMainLooper())
        } catch (_: SecurityException) {
            stopTracking()
        }
    }

    private fun stopTracking() {
        if (::fused.isInitialized) fused.removeLocationUpdates(callback)
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) { }
        wakeLock = null
        prefs.edit().putBoolean("tracking", false).commit()
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName)
            .putExtra("meters", prefs.getFloat("total_meters", 0f).toDouble()))
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Radhika Cab trip tracking", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(meters: Double): Notification = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentTitle("GPS TAXI METER – प्रवास सुरू आहे")
        .setContentText(String.format(java.util.Locale.US, "GPS अंतर: %.2f km | दर ₹25/km", meters / 1000.0))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .build()

    private fun updateNotification(meters: Double) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(meters))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.radhikacab.faremeter.START_TRIP"
        const val ACTION_STOP = "com.radhikacab.faremeter.STOP_TRIP"
        const val ACTION_UPDATE = "com.radhikacab.faremeter.TRIP_UPDATE"
        const val ACTION_STOPPED = "com.radhikacab.faremeter.TRIP_STOPPED"
        const val NOTIFICATION_ID = 2501
    }
}
