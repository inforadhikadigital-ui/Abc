package com.radhikacab.faremeter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.location.Geocoder
import android.location.Location
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import com.google.android.gms.tasks.CancellationTokenSource
import android.widget.EditText
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.round

class MainActivity : ComponentActivity() {
    private val farePerKm: Double get() = prefs.getFloat("fare_per_km", 21.0f).toDouble()
    private val prefs by lazy { getSharedPreferences("trip_state", MODE_PRIVATE) }
    private lateinit var statusText: TextView
    private lateinit var distanceText: TextView
    private lateinit var fareText: TextView
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var pdfButton: Button
    private var tracking = false
    private var totalMeters = 0.0
    private var startTime = ""
    private var endTime = ""
    private var paymentScreen = false
    private var driverName = ""
    private var activationInProgress = false
    private var startLocation = ""
    private var endLocation = ""
    private val createPdfCode = 202

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) requestNotificationPermission()
        else Toast.makeText(this, "अचूक GPS साठी Precise Location परवानगी द्या.", Toast.LENGTH_LONG).show()
    }
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val profilePhotoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            prefs.edit().putString("profile_photo_uri", uri.toString()).apply()
            showDriverProfile()
        }
    }

    private val tripReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            totalMeters = intent.getDoubleExtra("meters", totalMeters)
            tracking = prefs.getBoolean("tracking", false)
            if (intent.action == TripLocationService.ACTION_STOPPED) {
                endTime = now()
                statusText.text = "प्रवास पूर्ण • रोख रक्कम जमा करा"
            } else statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
            refreshNumbers()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreTripState()
        if (prefs.getBoolean("activation_ok", false)) {
            showDashboard()
            if (!hasFineLocationPermission()) requestLocationPermission() else requestNotificationPermission()
        } else {
            buildActivationScreen()
        }
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(TripLocationService.ACTION_UPDATE)
            addAction(TripLocationService.ACTION_STOPPED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(tripReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(tripReceiver, filter)
        restoreTripState()
    }

    override fun onStop() {
        try { unregisterReceiver(tripReceiver) } catch (_: IllegalArgumentException) { }
        super.onStop()
    }

    private fun restoreTripState() {
        tracking = prefs.getBoolean("tracking", false)
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        startTime = prefs.getString("start_time", "") ?: ""
        endTime = prefs.getString("end_time", "") ?: ""
        driverName = prefs.getString("driver_name", "") ?: ""
        startLocation = prefs.getString("start_location", "") ?: ""
        endLocation = prefs.getString("end_location", "") ?: ""
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
    private fun params(w: Int = -1, h: Int = -2, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, if (h == -2) -2 else dp(h)).apply { bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(0xFFEAF0F7.toInt())
    }

    private fun styledButton(title: String, color: Int): Button = Button(this).apply {
        text = title; textSize = 16f; isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(color)
    }

    private fun buildScreen() {
        paymentScreen = false
        window.statusBarColor = 0xFF061A36.toInt()
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(16))
            setBackgroundColor(0xFF061A36.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        header.addView(label("☰", 25f, 0xFFFFFFFF.toInt(), true),
            LinearLayout.LayoutParams(dp(48), dp(48)))
        header.addView(label("GPS TAXI METER", 22f, 0xFFFFFFFF.toInt(), true),
            LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label(if (tracking) "● GPS : ON" else "GPS : READY", 13f,
            0xFF35D05A.toInt(), true))
        root.addView(header, params(bottom = 8))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFF8FAFC.toInt()); cornerRadius = dp(22).toFloat()
            }
        }
        fun stat(title: String, value: String, icon: String, color: Int = 0xFF101827.toInt()): TextView {
            panel.addView(label("$icon   $title", 15f, 0xFF26364A.toInt(), true))
            return label(value, 29f, color, true).also { panel.addView(it, params(bottom = 8)) }
        }
        distanceText = stat("Distance", "0.00 km", "▰")
        val sep1 = View(this).apply { setBackgroundColor(0xFFE1E6EC.toInt()) }
        panel.addView(sep1, params(h = 1, bottom = 8))
        val tripTimeText = label("◷   Trip Time\n${elapsedTripText()}", 22f, 0xFF101827.toInt(), true)
        panel.addView(tripTimeText, params(bottom = 8))
        val sep2 = View(this).apply { setBackgroundColor(0xFFE1E6EC.toInt()) }
        panel.addView(sep2, params(h = 1, bottom = 8))
        fareText = label("Fare\n₹0.00", 28f, 0xFF07833F.toInt(), true)
        panel.addView(fareText, params(bottom = 8))
        panel.addView(label(String.format(Locale.US, "Rate : ₹%.2f / km", farePerKm), 17f, 0xFF101827.toInt(), true))
        root.addView(panel, params(bottom = 18))

        startButton = styledButton("▶   START", 0xFF08A52D.toInt()).apply {
            textSize = 24f
            setOnClickListener { startTrip() }
        }
        endButton = styledButton("■   STOP", 0xFFD92323.toInt()).apply {
            textSize = 22f
            setOnClickListener { endTrip() }
        }
        root.addView(startButton, params(h = 68, bottom = 10))
        root.addView(endButton, params(h = 58, bottom = 14))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            setBackgroundColor(0xFF102B4D.toInt())
        }
        fun navButton(title: String, action: () -> Unit) {
            nav.addView(styledButton(title, 0xFF102B4D.toInt()).apply {
                textSize = 14f; setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        navButton("▦\nTrips") { showHistory() }
        navButton("⚙\nRate") { showSettings() }
        navButton("●\nProfile") { showDriverProfile() }
        root.addView(nav, params(bottom = 10))
        pdfButton = styledButton("PDF BILL", 0xFF236DB5.toInt()).apply {
            setOnClickListener { createPdf() }
        }
        root.addView(pdfButton, params(h = 48, bottom = 8))
        statusText = label(if (tracking) "GPS tracking active" else "Ready to start your trip",
            13f, 0xFFDCE7F4.toInt())
        root.addView(statusText)
        scroll.addView(root)
        setContentView(scroll)
        refreshNumbers()
        startButton.isEnabled = !tracking
        endButton.isEnabled = tracking
        startButton.alpha = if (tracking) 0.45f else 1f
        endButton.alpha = if (tracking) 1f else 0.45f
    }

    private fun elapsedTripText(): String {
        if (startTime.isBlank()) return "00:00:00"
        return try {
            val start = SimpleDateFormat("hh:mm:ss a", Locale.US).parse(startTime)?.time ?: return "00:00:00"
            val seconds = ((System.currentTimeMillis() - start) / 1000).coerceAtLeast(0)
            String.format(Locale.US, "%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        } catch (_: Exception) { "00:00:00" }
    }

    private fun buildActivationScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF071323.toInt())
        }
        root.addView(label("GPS TAXI METER", 26f, 0xFF075B35.toInt(), true), params(bottom = 10))
        root.addView(label("मोबाईल Activation", 18f, 0xFF263445.toInt(), true), params(bottom = 18))
        val codeInput = EditText(this).apply {
            hint = "Activation Code टाका"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(codeInput, params(bottom = 12))

        // Show the exact identifier sent to Cloudflare so an existing binding can be checked safely.
        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            ?: "Device ID उपलब्ध नाही"
        root.addView(label("MY DEVICE ID", 13f, 0xFF526171.toInt(), true), params(bottom = 4))
        val deviceIdText = TextView(this).apply {
            text = deviceId
            textSize = 12f
            setTextColor(0xFF263445.toInt())
            gravity = Gravity.CENTER
            setTextIsSelectable(true)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(deviceIdText, params(bottom = 6))
        val copyDeviceId = styledButton("COPY DEVICE ID", 0xFF526171.toInt())
        copyDeviceId.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("GPS TAXI METER Device ID", deviceId))
            Toast.makeText(this, "Device ID कॉपी झाला", Toast.LENGTH_SHORT).show()
        }
        root.addView(copyDeviceId, params(h = 44, bottom = 12))

        val activate = styledButton("ACTIVATE", 0xFF07833F.toInt())
        activate.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isBlank()) { codeInput.error = "Activation Code आवश्यक आहे"; return@setOnClickListener }
            if (activationInProgress) return@setOnClickListener
            activationInProgress = true
            activate.isEnabled = false
            activate.text = "Checking..."
            Thread {
                var message = "Activation failed"
                var success = false
                try {
                    val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                        ?: throw IllegalStateException("Device ID मिळाला नाही")
                    val conn = (URL("https://radhika-cab-activation.kaleprafull2.workers.dev/").openConnection() as HttpURLConnection)
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 15000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    val body = JSONObject().put("code", code).put("deviceId", deviceId).toString()
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    success = status in 200..299
                    message = when {
                        status == 403 -> "हा Activation Code दुसऱ्या मोबाईलवर वापरला आहे."
                        success -> "Activation यशस्वी!"
                        else -> "Activation नाकारले (HTTP $status): $response"
                    }
                    conn.disconnect()
                } catch (e: Exception) { message = "Server कनेक्शन अयशस्वी: ${e.localizedMessage ?: "Unknown error"}" }
                runOnUiThread {
                    activationInProgress = false
                    activate.isEnabled = true
                    activate.text = "ACTIVATE"
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    if (success) {
                        prefs.edit().putBoolean("activation_ok", true).apply()
                        showDashboard()
                        if (!hasFineLocationPermission()) requestLocationPermission() else requestNotificationPermission()
                    }
                }
            }.start()
        }
        root.addView(activate, params(h = 54, bottom = 14))
        root.addView(label("एक Activation Code फक्त एका मोबाईलसाठी.", 13f, 0xFF526171.toInt()))
        setContentView(root)
    }

    private fun hasFineLocationPermission() =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationPermission() {
        locationPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun startTrip() {
        if (!hasFineLocationPermission()) { requestLocationPermission(); return }
        if (tracking) return
        totalMeters = 0.0; startTime = now(); endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", true)
            .putString("start_time", startTime).putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        captureLocation(true, true)
        val serviceIntent = Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, serviceIntent) else startService(serviceIntent)
            tracking = true
            buildScreen()
        } catch (e: Exception) {
            prefs.edit().putBoolean("tracking", false).commit()
            tracking = false
            Toast.makeText(this, "GPS Service सुरू झाली नाही: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            buildScreen()
        }
    }

    private fun endTrip() {
        if (!tracking) return
        startService(Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_STOP))
        tracking = false
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        endTime = now()
        prefs.edit().putBoolean("tracking", false).putString("end_time", endTime).commit()
        captureLocation(false)
        showTripSummaryScreen()
    }

    private fun roundedKm() = round((totalMeters / 1000.0) * 100.0) / 100.0
    private fun fareAmount() = round(roundedKm() * farePerKm * 100.0) / 100.0

    private fun showDashboard() {
        // Return to the main GPS meter screen.
        buildScreen()
    }

    private fun showTripSummaryScreen() {
        paymentScreen = false
        window.statusBarColor = 0xFF061A36.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF061A36.toInt())
            setPadding(dp(14), dp(10), dp(14), dp(14))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("‹", 34f, -1, true), LinearLayout.LayoutParams(dp(48), dp(52)))
        header.addView(label("Trip Summary", 22f, -1, true))
        root.addView(header, params(bottom = 10))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = dp(22).toFloat()
            }
        }
        val check = TextView(this).apply {
            text = "✓"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(-1)
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFFF8A00.toInt())
            }
        }
        panel.addView(check, LinearLayout.LayoutParams(dp(58), dp(58)).apply {
            bottomMargin = dp(8)
        })
        panel.addView(label("Trip Completed", 23f, 0xFF101827.toInt(), true), params(bottom = 12))

        fun summaryRow(title: String, value: String) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(12), dp(4), dp(12))
            }
            line.addView(label(title, 15f, 0xFF26364A.toInt(), true),
                LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(label(value, 17f, 0xFF101827.toInt(), true))
            panel.addView(line)
            panel.addView(View(this).apply {
                setBackgroundColor(0xFFE5E7EB.toInt())
            }, params(h = 1))
        }

        summaryRow("Distance", String.format(Locale.US, "%.2f km", roundedKm()))
        summaryRow("Trip Time", if (startTime.isNotBlank())
            "$startTime - ${endTime.ifBlank { now() }}" else "Not available")
        summaryRow("Rate", String.format(Locale.US, "₹%.2f / km", farePerKm))

        val total = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFE4F8E4.toInt())
                cornerRadius = dp(16).toFloat()
            }
        }
        total.addView(label("Total Fare", 18f, 0xFF101827.toInt(), true))
        total.addView(label(String.format(Locale.US, "₹%.2f", fareAmount()),
            30f, 0xFF07833F.toInt(), true))
        panel.addView(total, params(bottom = 16))

        panel.addView(styledButton("₹   Continue to Payment", 0xFFFF8500.toInt()).apply {
            textSize = 18f
            setOnClickListener { showPaymentScreen() }
        }, params(h = 58, bottom = 10))
        panel.addView(styledButton("⟳   New Trip", 0xFFFFFFFF.toInt()).apply {
            setTextColor(0xFF101827.toInt())
            setOnClickListener { buildScreen() }
        }, params(h = 52))
        root.addView(panel, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun showPaymentScreen() {
        paymentScreen = true
        window.statusBarColor = 0xFF061A36.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF061A36.toInt())
            setPadding(dp(14), dp(10), dp(14), dp(14))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 34f, -1, true), LinearLayout.LayoutParams(dp(48), dp(52)))
        header.addView(label("Cash Collection", 22f, -1, true))
        root.addView(header, params(bottom = 10))
        val white = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(24), dp(18), dp(20))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(22).toFloat()
            }
        }
        val greenPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(14), dp(22), dp(14), dp(22))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFE7F9E6.toInt()); cornerRadius = dp(18).toFloat()
            }
        }
        greenPanel.addView(label("▤", 48f, 0xFF07833F.toInt(), true), params(bottom = 8))
        greenPanel.addView(label("Collect Cash", 22f, 0xFF101827.toInt(), true), params(bottom = 14))
        greenPanel.addView(label(String.format(Locale.US, "₹%.2f", fareAmount()), 42f, 0xFF075B2A.toInt(), true), params(bottom = 8))
        greenPanel.addView(label("From Passenger", 18f, 0xFF101827.toInt()))
        white.addView(greenPanel, params(bottom = 18))
        white.addView(styledButton("✓   CASH COLLECTED", 0xFF079B2F.toInt()).apply {
            textSize = 19f; setOnClickListener { saveTripAndReturn() }
        }, params(h = 62, bottom = 12))
        white.addView(styledButton("▤   Save Receipt", 0xFFFFFFFF.toInt()).apply {
            setTextColor(0xFF101827.toInt()); setOnClickListener { createPdf() }
        }, params(h = 54, bottom = 10))
        white.addView(styledButton("⌂   Go to Home", 0xFFFFFFFF.toInt()).apply {
            setTextColor(0xFF101827.toInt()); setOnClickListener { showDashboard() }
        }, params(h = 54))
        root.addView(white, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun saveTripAndReturn() {
        val history = prefs.getString("history", "") ?: ""
        val record = "${now()} | ${String.format(Locale.US, "%.2f", roundedKm())} km | ₹${String.format(Locale.US, "%.2f", fareAmount())}"
        prefs.edit().putString("history", if (history.isBlank()) record else "$record\n$history")
            .putFloat("income_total", (prefs.getFloat("income_total", 0f).toDouble() + fareAmount()).toFloat()).commit()
        totalMeters = 0.0; tracking = false; startTime = ""; endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", false)
            .putString("start_time", "").putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        showDashboard()
        AlertDialog.Builder(this).setTitle("Payment Collected")
            .setMessage("Cash payment has been recorded.")
            .setPositiveButton("OK", null).show()
    }

    private fun prompt(title: String, hint: String, initial: String = "", onSave: (String) -> Unit) {
        val input = EditText(this).apply { setSingleLine(true); this.hint = hint; setText(initial); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("Save") { _, _ -> onSave(input.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showDailyAccounts() {
        val income = prefs.getFloat("income_total", 0f).toDouble()
        val expense = prefs.getFloat("expense_total", 0f).toDouble()
        val msg = "एकूण कमाई: ₹%.2f\\nएकूण खर्च: ₹%.2f\\nनिव्वळ शिल्लक: ₹%.2f".format(income, expense, income-expense)
        AlertDialog.Builder(this).setTitle("Daily Income & Expense").setMessage(msg)
            .setPositiveButton("खर्च जोडा") { _, _ -> prompt("खर्चाची रक्कम (₹)", "उदा. 250") { value ->
                val amount = value.toDoubleOrNull()
                if (amount == null || amount < 0) Toast.makeText(this,"योग्य रक्कम टाका",Toast.LENGTH_SHORT).show()
                else { prefs.edit().putFloat("expense_total", (prefs.getFloat("expense_total",0f)+amount.toFloat())).apply(); showDailyAccounts() }
            } }
            .setNeutralButton("आजचा हिशोब Reset") { _, _ ->
                AlertDialog.Builder(this).setMessage("कमाई व खर्चाचे एकूण आकडे Reset करायचे?").setPositiveButton("Reset") { _, _ -> prefs.edit().putFloat("income_total",0f).putFloat("expense_total",0f).apply(); showDailyAccounts() }.setNegativeButton("Cancel",null).show()
            }.setNegativeButton("बंद",null).show()
    }

    private fun showVehicleReminders() {
        val docs = listOf("Insurance", "PUC", "Fitness Certificate", "Driving Licence", "Permit")
        val saved = docs.map { it to (prefs.getString("expiry_$it", "") ?: "") }
        val lines = saved.joinToString("\\n") { (name,date) -> "$name : ${date.ifBlank { "Date not set" }}" }
        AlertDialog.Builder(this).setTitle("Vehicle Document Reminders").setMessage(lines)
            .setPositiveButton("Expiry Date Set") { _, _ ->
                val options = docs.toTypedArray()
                AlertDialog.Builder(this).setTitle("Document निवडा").setItems(options) { _, which ->
                    val doc=options[which]
                    prompt("$doc expiry date", "YYYY-MM-DD", prefs.getString("expiry_$doc","") ?: "") { date ->
                        prefs.edit().putString("expiry_$doc",date).apply()
                        Toast.makeText(this,"$doc तारीख सेव्ह झाली",Toast.LENGTH_SHORT).show()
                    }
                }.show()
            }
            .setNeutralButton("WhatsApp Contact") { _, _ -> sendDocumentHelpWhatsApp("माझ्या वाहनाच्या कागदपत्राबाबत मदत हवी आहे.") }
            .setNegativeButton("बंद",null).show()
        // Expired documents can be sent to the requested support number with a prefilled message.
        val expired = saved.filter { (_,date) -> date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && date < java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
        if (expired.isNotEmpty()) {
            val doc = expired.first().first
            AlertDialog.Builder(this).setTitle("Document Expired").setMessage("$doc संपले आहे. अपडेट/मदतीसाठी WhatsApp संदेश पाठवायचा?")
                .setPositiveButton("WhatsApp संदेश") { _, _ -> sendDocumentHelpWhatsApp("$doc संपला आहे. कृपया अपडेट करण्यासाठी संपर्क करा.") }
                .setNegativeButton("नंतर",null).show()
        }
    }

    private fun sendDocumentHelpWhatsApp(message: String) {
        try {
            val uri = android.net.Uri.parse("https://wa.me/919710409696?text=" + java.net.URLEncoder.encode(message, "UTF-8"))
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) { Toast.makeText(this,"WhatsApp उघडता आले नाही",Toast.LENGTH_LONG).show() }
    }

    private fun showVehicleManagement() {
        val vehicle = prefs.getString("vehicle_number", "") ?: ""
        val type = prefs.getString("vehicle_type", "") ?: ""
        val fuel = prefs.getString("fuel_type", "") ?: ""
        AlertDialog.Builder(this).setTitle("Vehicle Management")
            .setMessage("Vehicle: ${vehicle.ifBlank { "Not set" }}\\nType: ${type.ifBlank { "Not set" }}\\nFuel: ${fuel.ifBlank { "Not set" }}\\nService KM: ${prefs.getString("service_km", "Not set")}")
            .setPositiveButton("Vehicle Number") { _, _ -> prompt("Vehicle Number", "MH12AB1234", vehicle) { prefs.edit().putString("vehicle_number",it).apply(); showVehicleManagement() } }
            .setNeutralButton("Vehicle / Fuel") { _, _ ->
                val fields = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),0) }
                val t=EditText(this).apply { hint="Vehicle type (Car/Taxi)"; setText(type) }; val f=EditText(this).apply { hint="Fuel (CNG/Petrol/Diesel/EV)"; setText(fuel) }; val k=EditText(this).apply { hint="Next service at KM"; setText(prefs.getString("service_km","") ?: "") }
                fields.addView(t);fields.addView(f);fields.addView(k)
                AlertDialog.Builder(this).setTitle("Vehicle Details").setView(fields).setPositiveButton("Save") { _, _ -> prefs.edit().putString("vehicle_type",t.text.toString()).putString("fuel_type",f.text.toString()).putString("service_km",k.text.toString()).apply() }.setNegativeButton("Cancel",null).show()
            }.setNegativeButton("बंद",null).show()
    }

    private fun showDriverSafety() {
        val contact=prefs.getString("sos_contact","") ?: ""
        AlertDialog.Builder(this).setTitle("Driver Safety / SOS")
            .setMessage("Emergency Contact: ${contact.ifBlank { "Not set" }}\\nSOS दाबल्यावर निवडलेल्या संपर्काला कॉल सुरू होईल.")
            .setPositiveButton("SOS Call") { _, _ ->
                if (contact.isBlank()) prompt("Emergency Contact Number", "मोबाईल नंबर") { prefs.edit().putString("sos_contact",it).apply(); showDriverSafety() }
                else try { startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$contact"))) } catch (_: Exception) { }
            }
            .setNeutralButton("Contact Set") { _, _ -> prompt("Emergency Contact Number", "मोबाईल नंबर",contact) { prefs.edit().putString("sos_contact",it).apply() } }
            .setNegativeButton("बंद",null).show()
    }

    private fun chooseLanguage() {
        val langs=arrayOf("मराठी", "हिंदी", "English")
        AlertDialog.Builder(this).setTitle("App Language").setSingleChoiceItems(langs, prefs.getInt("language_index",0)) { dialog, which ->
            prefs.edit().putInt("language_index",which).apply(); dialog.dismiss()
            Toast.makeText(this,"भाषा निवड सेव्ह झाली. काही स्क्रीनवरील भाषांतर पुढील अपडेटमध्ये पूर्ण होईल.",Toast.LENGTH_LONG).show()
        }.setNegativeButton("Cancel",null).show()
    }

    private fun showHistory() {
        val history = prefs.getString("history", "") ?: ""
        AlertDialog.Builder(this).setTitle("प्रवास नोंदी (History)")
            .setMessage(if (history.isBlank()) "अजून कोणताही पूर्ण प्रवास नाही." else history.replace("\n", "\n"))
            .setPositiveButton("OK", null).show()
    }


    private fun showDriverProfile() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFF071323.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("DRIVER PROFILE", 24f, 0xFFFFA51F.toInt(), true), params(bottom = 14))

        val photoUri = prefs.getString("profile_photo_uri", null)
        val photo = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(104), dp(104)).apply { gravity = Gravity.CENTER; bottomMargin = dp(10) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF17263A.toInt())
            if (!photoUri.isNullOrBlank()) {
                try { setImageURI(android.net.Uri.parse(photoUri)) } catch (_: Exception) { }
            }
        }
        content.addView(photo)
        content.addView(styledButton("CHANGE PROFILE PHOTO", 0xFF34445B.toInt()).apply {
            setOnClickListener { profilePhotoPicker.launch("image/*") }
        }, params(h = 48, bottom = 16))

        fun field(title: String, key: String, hintText: String): EditText {
            content.addView(label(title, 13f, 0xFFCAD5E3.toInt(), true), params(bottom = 4))
            val edit = EditText(this).apply {
                setSingleLine(true)
                hint = hintText
                setText(prefs.getString(key, "") ?: "")
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
                setHintTextColor(0xFF9AAABD.toInt())
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(0xFF17263A.toInt())
            }
            content.addView(edit, params(bottom = 12))
            return edit
        }
        val name = field("DRIVER NAME", "driver_name", "Enter driver name")
        val mobile = field("MOBILE NUMBER", "driver_mobile", "Enter mobile number")
        val vehicleNo = field("VEHICLE NUMBER", "vehicle_number", "e.g. MH12AB1234")
        val vehicleType = field("VEHICLE TYPE", "vehicle_type", "Car / Auto / Bike")
        val vehicleModel = field("VEHICLE MODEL", "vehicle_model", "Enter vehicle model")
        val emergency = field("EMERGENCY CONTACT", "emergency_contact", "Enter emergency number")

        content.addView(styledButton("SAVE / UPDATE PROFILE", 0xFF0866E8.toInt()).apply {
            setOnClickListener {
                driverName = name.text.toString().trim()
                prefs.edit()
                    .putString("driver_name", driverName)
                    .putString("driver_mobile", mobile.text.toString().trim())
                    .putString("vehicle_number", vehicleNo.text.toString().trim())
                    .putString("vehicle_type", vehicleType.text.toString().trim())
                    .putString("vehicle_model", vehicleModel.text.toString().trim())
                    .putString("emergency_contact", emergency.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        }, params(h = 56, bottom = 10))
        content.addView(styledButton("BACK TO DASHBOARD", 0xFF34445B.toInt()).apply {
            setOnClickListener { showDashboard() }
        }, params(h = 48))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(arrayOf("Fare Rate (₹ / km)", "Driver Name")) { _, which ->
                if (which == 0) showFareRateSetting() else showDriverNameSetting()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showFareRateSetting() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(String.format(Locale.US, "%.2f", farePerKm))
            hint = "उदा. 21"
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this)
            .setTitle("Set Fare Rate")
            .setMessage("प्रति किलोमीटर दर कमी किंवा जास्त करा.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val rate = input.text.toString().trim().toDoubleOrNull()
                if (rate == null || rate <= 0.0 || rate > 10000.0) {
                    Toast.makeText(this, "कृपया योग्य दर टाका.", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putFloat("fare_per_km", rate.toFloat()).apply()
                    Toast.makeText(this, String.format(Locale.US, "Rate saved: ₹%.2f/km", rate), Toast.LENGTH_SHORT).show()
                    buildScreen()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDriverNameSetting() {
        val input = EditText(this).apply {
            setSingleLine(true); setText(driverName); hint = "Driver name"
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("Change Driver Name")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                driverName = input.text.toString().trim()
                prefs.edit().putString("driver_name", driverName).apply()
                buildScreen()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun editLocation(isStart: Boolean) {
        val input = EditText(this).apply {
            setText(if (isStart) startLocation else endLocation)
            hint = "ठिकाण / पत्ता लिहा"; minLines = 2
        }
        AlertDialog.Builder(this)
            .setTitle(if (isStart) "Start Location बदला" else "End Location बदला")
            .setView(input)
            .setPositiveButton("सेव्ह करा") { _, _ ->
                val value = input.text.toString().trim()
                if (isStart) startLocation = value else endLocation = value
                prefs.edit().putString(if (isStart) "start_location" else "end_location", value).apply()
                buildScreen()
            }
            .setNeutralButton("Automatic GPS") { _, _ -> captureLocation(isStart, true) }
            .setNegativeButton("रद्द", null).show()
    }

    @Suppress("MissingPermission")
    private fun captureLocation(isStart: Boolean, redraw: Boolean = false) {
        if (!hasFineLocationPermission()) return
        val client = LocationServices.getFusedLocationProviderClient(this)
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                if (loc == null) {
                    client.lastLocation.addOnSuccessListener { last ->
                        if (last != null) saveLocationAddress(last, isStart, redraw)
                        else Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
                    }
                } else saveLocationAddress(loc, isStart, redraw)
            }
            .addOnFailureListener {
                Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
            }
    }

    @Suppress("DEPRECATION")
    private fun saveLocationAddress(location: Location, isStart: Boolean, redraw: Boolean) {
        try {
            val geocoder = Geocoder(this, Locale("mr", "IN"))
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val address = addresses?.firstOrNull()?.getAddressLine(0)
                ?: String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = address else endLocation = address
            prefs.edit().putString(if (isStart) "start_location" else "end_location", address).apply()
        } catch (_: Exception) {
            val coordinates = String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = coordinates else endLocation = coordinates
            prefs.edit().putString(if (isStart) "start_location" else "end_location", coordinates).apply()
        }
        if (paymentScreen) showPaymentScreen() else if (redraw) buildScreen()
    }

    private fun refreshNumbers() {
        val km = roundedKm()
        if (::distanceText.isInitialized) distanceText.text = String.format(Locale.US, "%.2f km", km)
        if (::fareText.isInitialized) fareText.text = String.format(Locale.US, "₹%.2f", fareAmount())
        if (::startButton.isInitialized) {
            startButton.isEnabled = !tracking
            startButton.alpha = if (tracking) .45f else 1f
            endButton.isEnabled = tracking
            endButton.alpha = if (tracking) 1f else .45f
            pdfButton.isEnabled = !tracking && endTime.isNotBlank()
            pdfButton.alpha = if (pdfButton.isEnabled) 1f else .55f
        }
    }

    private fun now() = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale("en", "IN")).format(Date())

    private fun createPdf() {
        if (endTime.isBlank()) {
            Toast.makeText(this, "प्रवास संपल्यानंतर PDF बिल डाउनलोड करा.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "GPS_TAXI_METER_Bill_${System.currentTimeMillis()}.pdf")
        }
        startActivityForResult(intent, createPdfCode)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createPdfCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { writePdf(it) }
                Toast.makeText(this, "PDF बिल सेव झाले.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "PDF सेव करताना त्रुटी: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writePdf(out: OutputStream) {
        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 20f }
        paint.textSize = 28f; paint.isFakeBoldText = true; canvas.drawText("GPS TAXI METER", 50f, 70f, paint)
        paint.textSize = 16f; paint.isFakeBoldText = false; canvas.drawText("GPS TRIP BILL", 50f, 105f, paint)
        canvas.drawLine(50f, 125f, 545f, 125f, paint)
        paint.textSize = 18f
        val lines = listOf(
            "Driver: $driverName", "Trip date: $startTime", "Trip ended: $endTime",
            "Start location: ${startLocation.ifBlank { "Not available" }}",
            "End location: ${endLocation.ifBlank { "Not available" }}",
            String.format(Locale.US, "Distance: %.2f km", roundedKm()),
            String.format(Locale.US, "Rate: Rs. %.2f per km", farePerKm),
            String.format(Locale.US, "TOTAL FARE: Rs. %.2f", fareAmount())
        )
        var y = 180f
        for (line in lines) {
            var remaining = line
            while (remaining.isNotEmpty()) {
                val count = paint.breakText(remaining, true, 490f, null)
                if (count <= 0) break
                canvas.drawText(remaining.substring(0, count), 50f, y, paint)
                remaining = remaining.substring(count).trimStart()
                y += 28f
            }
            y += 14f
        }
        paint.textSize = 12f
        canvas.drawText("Distance is calculated using device GPS. Actual accuracy may vary.", 50f, minOf(y + 20f, 800f), paint)
        pdf.finishPage(page); pdf.writeTo(out); pdf.close()
    }
}
