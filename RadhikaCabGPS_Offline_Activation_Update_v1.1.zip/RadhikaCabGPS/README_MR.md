# Radhika Cab GPS Fare Meter – Updated

- भाडे दर: ₹25 प्रति km
- START / END प्रवास नियंत्रण
- GPS Foreground Service द्वारे Background tracking
- पेमेंट स्क्रीन: PAY IN CASH
- PDF बिल डाउनलोड
- CASH COLLECTED नंतर धन्यवाद संदेश व मुख्य स्क्रीन
- प्रवास History व Settings

## Build
Android project root मधून `gradle clean assembleDebug` चालवा.
APK: `app/build/outputs/apk/debug/app-debug.apk`

## महत्त्वाच्या सूचना
- पहिल्यांदा वापरताना Precise Location आणि Notifications परवानगी द्या.
- Android Settings मध्ये Radhika Cab साठी Battery usage `Unrestricted`/`Allow background activity` उपलब्ध असल्यास निवडा.
- GPS अंतराची अचूकता फोन, सिग्नल आणि GPS परिस्थितीवर अवलंबून असते. प्रत्यक्ष प्रवासात भाडे तपासूनच वापरा.
- या आवृत्तीत नकाशा पॅनल हे GPS स्थिती दाखवणारे डिझाइन पॅनल आहे; Google Maps नकाशा API जोडलेला नाही.


## या अपडेटमधील नवीन सुविधा
- Settings मधून ड्रायव्हरचे नाव बदलता येते; नाव फोनमध्ये सेव्ह राहते.
- START करताना सुरुवातीचे GPS ठिकाण आपोआप मिळवण्याचा प्रयत्न होतो.
- END करताना शेवटचे GPS ठिकाण आपोआप मिळवण्याचा प्रयत्न होतो.
- Start Location आणि End Location साठी Manual Edit आणि Automatic GPS पर्याय.
- Payment स्क्रीन आणि PDF बिलात ड्रायव्हरचे नाव, सुरुवात व शेवटचे ठिकाण.
- GPS पत्ता मिळाला नाही किंवा Geocoder उपलब्ध नसेल तर अक्षांश/रेखांश दाखवले जातात; Manual Edit वापरता येतो.

## Build बाबत
या ZIP मध्ये Gradle Wrapper executable/JAR समाविष्ट नाही. त्यामुळे Android Studio/Gradle असलेल्या संगणकावर प्रोजेक्ट उघडून Gradle Sync करून APK build करावा. या वातावरणात APK build किंवा प्रत्यक्ष Android GPS चाचणी केलेली नाही.


## Offline Activation (Version 1.1)
- App launch now displays an Activation screen until a valid code from the bundled 500-code list is entered.
- After activation, the app stores a local activation flag and device UUID; normal relaunch on the same installation does not ask again.
- Factory reset or clearing app data removes local activation and requires activation again.
- IMPORTANT: Because this is fully offline, the app cannot globally mark a code as used. A copied code may activate another device too. Global one-time use and reliable duplicate prevention require an online server. The local device lock is a deterrent, not tamper-proof protection.
- Android update installation requires signing the new APK with the same signing key as the installed APK. Do not uninstall the existing app before updating, or local trip data/activation may be lost.
