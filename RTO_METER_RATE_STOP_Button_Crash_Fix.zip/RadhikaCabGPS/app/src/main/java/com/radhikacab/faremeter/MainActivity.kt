package com.radhikacab.faremeter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.location.Geocoder
import android.location.Location
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import com.google.android.gms.tasks.CancellationTokenSource
import android.widget.EditText
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.round

class MainActivity : ComponentActivity() {
    private val farePerKm = 25.0
    private val prefs by lazy { getSharedPreferences("trip_state", MODE_PRIVATE) }
    private lateinit var statusText: TextView
    private lateinit var distanceText: TextView
    private lateinit var fareText: TextView
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var pdfButton: Button
    private var tracking = false
    private var totalMeters = 0.0
    private var startTime = ""
    private var endTime = ""
    private var paymentScreen = false
    private var driverName = ""
    private var activationInProgress = false
    private var startLocation = ""
    private var endLocation = ""
    private val createPdfCode = 202

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) requestNotificationPermission()
        else Toast.makeText(this, "अचूक GPS साठी Precise Location परवानगी द्या.", Toast.LENGTH_LONG).show()
    }
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val profilePhotoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            prefs.edit().putString("profile_photo_uri", uri.toString()).apply()
            showDriverProfile()
        }
    }

    private val tripReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            totalMeters = intent.getDoubleExtra("meters", totalMeters)
            tracking = prefs.getBoolean("tracking", false)
            if (intent.action == TripLocationService.ACTION_STOPPED) {
                endTime = now()
                statusText.text = "प्रवास पूर्ण • रोख रक्कम जमा करा"
            } else statusText.text = "प्रवास सुरू आहे • Background GPS चालू"
            refreshNumbers()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreTripState()
        if (prefs.getBoolean("activation_ok", false)) {
            showDashboard()
            if (!hasFineLocationPermission()) requestLocationPermission() else requestNotificationPermission()
        } else {
            buildActivationScreen()
        }
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(TripLocationService.ACTION_UPDATE)
            addAction(TripLocationService.ACTION_STOPPED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(tripReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(tripReceiver, filter)
        restoreTripState()
    }

    override fun onStop() {
        try { unregisterReceiver(tripReceiver) } catch (_: IllegalArgumentException) { }
        super.onStop()
    }

    private fun restoreTripState() {
        tracking = prefs.getBoolean("tracking", false)
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        startTime = prefs.getString("start_time", "") ?: ""
        endTime = prefs.getString("end_time", "") ?: ""
        driverName = prefs.getString("driver_name", "") ?: ""
        startLocation = prefs.getString("start_location", "") ?: ""
        endLocation = prefs.getString("end_location", "") ?: ""
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
    private fun params(w: Int = -1, h: Int = -2, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, if (h == -2) -2 else dp(h)).apply { bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(0xFFEAF0F7.toInt())
    }

    private fun styledButton(title: String, color: Int): Button = Button(this).apply {
        text = title; textSize = 16f; isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(color)
    }

    private fun buildScreen() {
        paymentScreen = false
        window.statusBarColor = 0xFF05080E.toInt()
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(16))
            setBackgroundColor(0xFF071323.toInt())
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(label("‹", 34f, -1, true).apply {
            setOnClickListener { showDashboard() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        top.addView(label("GPS Meter", 22f, -1, true).apply {
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(top, params(bottom = 12))

        val gpsPill = TextView(this).apply {
            text = if (tracking) "🟢  GPS : Strong" else "📍  GPS : Ready"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            setBackgroundColor(0xFF17263A.toInt())
        }
        root.addView(gpsPill, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.END
            bottomMargin = dp(18)
        })

        val fareCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(18), dp(14), dp(18))
            setBackgroundColor(0xFF101D30.toInt())
        }
        fareCard.addView(label("Fare (₹)", 21f, -1, true), params(bottom = 4))
        fareText = label(String.format(Locale.US, "%.2f", fareAmount()), 52f, 0xFFFF9D00.toInt(), true)
        fareText.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
        fareCard.addView(fareText)
        root.addView(fareCard, params(bottom = 14))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun statRow(leftTitle: String, leftValue: String, rightTitle: String, rightValue: String,
                    leftIcon: String, rightIcon: String) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun stat(title: String, value: String, icon: String): LinearLayout {
                return LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(12), dp(8), dp(12))
                    setBackgroundColor(0xFF17263A.toInt())
                    addView(label("$icon  $title", 14f, 0xFFD7E1EF.toInt(), true))
                    addView(label(value, 20f, -1, true))
                }
            }
            row.addView(stat(leftTitle, leftValue, leftIcon),
                LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginEnd = dp(6) })
            row.addView(stat(rightTitle, rightValue, rightIcon),
                LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginStart = dp(6) })
            stats.addView(row, params(bottom = 10))
        }
        statRow("Distance", String.format(Locale.US, "%.2f km", roundedKm()),
            "Time", if (tracking && startTime.isNotBlank()) startTime else "00:00:00", "📍", "◷")
        statRow("Speed", "— km/h", "Rate", String.format(Locale.US, "₹%.2f/km", farePerKm), "◉", "▤")
        root.addView(stats)

        startButton = styledButton("▶  START", 0xFF07833F.toInt()).apply {
            setOnClickListener { startTrip() }
        }
        endButton = styledButton("■  STOP", 0xFFE00000.toInt()).apply {
            textSize = 22f
            setOnClickListener { endTrip() }
        }
        endButton.visibility = if (tracking) View.VISIBLE else View.GONE
        startButton.visibility = if (tracking) View.GONE else View.VISIBLE
        root.addView(endButton, params(h = 62, bottom = 10))
        root.addView(startButton, params(h = 62, bottom = 10))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(styledButton("Ⅱ  PAUSE", 0xFFFFA500.toInt()).apply {
            setTextColor(0xFF101820.toInt())
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Pause control is not enabled yet.", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        controls.addView(styledButton("▶  RESUME", 0xFF17263A.toInt()).apply {
            setOnClickListener {
                Toast.makeText(this@MainActivity, "GPS trip is running when START is active.", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        root.addView(controls, params(bottom = 24))

        val rateCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFF17263A.toInt())
        }
        rateCard.addView(label("ⓘ   RTO Meter Rate (Car)     ✎", 16f, -1, true))
        rateCard.addView(label(String.format(Locale.US, "Base Fare : ₹25.00   |   Per Km : ₹%.2f", farePerKm),
            13f, 0xFFE0E7F0.toInt()))
        root.addView(rateCard, params(bottom = 14))

        root.addView(styledButton("TRIP HISTORY", 0xFF17263A.toInt()).apply {
            setOnClickListener { showHistory() }
        }, params(h = 48, bottom = 8))
        root.addView(styledButton("BACK TO HOME", 0xFF17263A.toInt()).apply {
            setOnClickListener { showDashboard() }
        }, params(h = 48))
        scroll.addView(root)
        setContentView(scroll)
        refreshNumbers()
    }

    private fun buildActivationScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF071323.toInt())
        }
        root.addView(label("RTO METER RATE", 26f, 0xFF075B35.toInt(), true), params(bottom = 10))
        root.addView(label("मोबाईल Activation", 18f, 0xFF263445.toInt(), true), params(bottom = 18))
        val codeInput = EditText(this).apply {
            hint = "Activation Code टाका"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(codeInput, params(bottom = 12))

        // Show the exact identifier sent to Cloudflare so an existing binding can be checked safely.
        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            ?: "Device ID उपलब्ध नाही"
        root.addView(label("MY DEVICE ID", 13f, 0xFF526171.toInt(), true), params(bottom = 4))
        val deviceIdText = TextView(this).apply {
            text = deviceId
            textSize = 12f
            setTextColor(0xFF263445.toInt())
            gravity = Gravity.CENTER
            setTextIsSelectable(true)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(deviceIdText, params(bottom = 6))
        val copyDeviceId = styledButton("COPY DEVICE ID", 0xFF526171.toInt())
        copyDeviceId.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("RTO METER RATE Device ID", deviceId))
            Toast.makeText(this, "Device ID कॉपी झाला", Toast.LENGTH_SHORT).show()
        }
        root.addView(copyDeviceId, params(h = 44, bottom = 12))

        val activate = styledButton("ACTIVATE", 0xFF07833F.toInt())
        activate.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isBlank()) { codeInput.error = "Activation Code आवश्यक आहे"; return@setOnClickListener }
            if (activationInProgress) return@setOnClickListener
            activationInProgress = true
            activate.isEnabled = false
            activate.text = "Checking..."
            Thread {
                var message = "Activation failed"
                var success = false
                try {
                    val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                        ?: throw IllegalStateException("Device ID मिळाला नाही")
                    val conn = (URL("https://radhika-cab-activation.kaleprafull2.workers.dev/").openConnection() as HttpURLConnection)
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 15000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    val body = JSONObject().put("code", code).put("deviceId", deviceId).toString()
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    success = status in 200..299
                    message = when {
                        status == 403 -> "हा Activation Code दुसऱ्या मोबाईलवर वापरला आहे."
                        success -> "Activation यशस्वी!"
                        else -> "Activation नाकारले (HTTP $status): $response"
                    }
                    conn.disconnect()
                } catch (e: Exception) { message = "Server कनेक्शन अयशस्वी: ${e.localizedMessage ?: "Unknown error"}" }
                runOnUiThread {
                    activationInProgress = false
                    activate.isEnabled = true
                    activate.text = "ACTIVATE"
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    if (success) {
                        prefs.edit().putBoolean("activation_ok", true).apply()
                        showDashboard()
                        if (!hasFineLocationPermission()) requestLocationPermission() else requestNotificationPermission()
                    }
                }
            }.start()
        }
        root.addView(activate, params(h = 54, bottom = 14))
        root.addView(label("एक Activation Code फक्त एका मोबाईलसाठी.", 13f, 0xFF526171.toInt()))
        setContentView(root)
    }

    private fun hasFineLocationPermission() =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocationPermission() {
        locationPermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun startTrip() {
        if (!hasFineLocationPermission()) { requestLocationPermission(); return }
        if (tracking) return
        totalMeters = 0.0; startTime = now(); endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", true)
            .putString("start_time", startTime).putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        captureLocation(true, true)
        val serviceIntent = Intent(this, TripLocationService::class.java).setAction(TripLocationService.ACTION_START)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, serviceIntent) else startService(serviceIntent)
            tracking = true
            buildScreen()
        } catch (e: Exception) {
            prefs.edit().putBoolean("tracking", false).commit()
            tracking = false
            Toast.makeText(this, "GPS Service सुरू झाली नाही: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            buildScreen()
        }
    }

    private fun endTrip() {
        if (!tracking) return
        try {
            val stopIntent = Intent(this, TripLocationService::class.java)
                .setAction(TripLocationService.ACTION_STOP)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(this, stopIntent)
            } else {
                startService(stopIntent)
            }
        } catch (e: Exception) {
            // Continue to the trip summary even if Android refuses the service stop request.
            android.util.Log.e("RTOMeter", "Could not send GPS stop action", e)
        }

        tracking = false
        totalMeters = prefs.getFloat("total_meters", 0f).toDouble()
        endTime = now()
        prefs.edit().putBoolean("tracking", false)
            .putString("end_time", endTime)
            .putFloat("total_meters", totalMeters.toFloat())
            .commit()

        // Open the summary immediately; location lookup is optional and must not block STOP.
        showTripSummaryScreen()
        try {
            captureLocation(false)
        } catch (e: Exception) {
            android.util.Log.w("RTOMeter", "Final location capture failed", e)
        }
    }

    private fun roundedKm() = round((totalMeters / 1000.0) * 100.0) / 100.0
    private fun fareAmount() = round(roundedKm() * farePerKm * 100.0) / 100.0

    private fun showPaymentScreen() {
        paymentScreen = true
        window.statusBarColor = 0xFF071323.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, dp(12))
        }
        val green = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(0xFF008A3B.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("RTO METER RATE", 21f, 0xFFFFD54F.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(styledButton("ⓘ HELP", 0xFF087A37.toInt()).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("Trip completed")
                    .setMessage("Tap CASH COLLECTED after receiving the fare.")
                    .setPositiveButton("OK", null).show()
            }
        }, params(-2, 44))
        green.addView(top, params(bottom = 18))
        green.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        green.addView(label(String.format(Locale.US, "₹ %.2f", fareAmount()), 54f, -1, true), params(bottom = 18))
        green.addView(label("Trip Completed Successfully", 21f, -1, true), params(bottom = 22))
        green.addView(label("${driverName.ifBlank { "Driver" }} to Pay in Cash", 19f, -1))
        green.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(green)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(22), dp(18), dp(22), dp(8)); setBackgroundColor(-1)
        }
        actions.addView(styledButton("DOWNLOAD PDF BILL", 0xFFE9EEF4.toInt()).apply {
            setTextColor(0xFF173B2A.toInt()); setOnClickListener { createPdf() }
        }, params(h = 44, bottom = 10))
        actions.addView(styledButton("CASH COLLECTED", 0xFF0866E8.toInt()).apply {
            textSize = 20f; setOnClickListener { saveTripAndReturn() }
        }, params(h = 66))
        root.addView(actions)
        setContentView(root)
    }

    private fun showTripSummaryScreen() {
        paymentScreen = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(0xFF071323.toInt())
        }
        root.addView(label("TRIP SUMMARY", 25f, 0xFFFFFFFF.toInt(), true), params(bottom = 18))
        root.addView(label("✓", 54f, 0xFF57D66B.toInt(), true), params(bottom = 4))
        root.addView(label("Trip Completed", 23f, -1, true), params(bottom = 18))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(0xFF17263A.toInt())
        }
        fun row(title: String, value: String, color: Int = -1) {
            panel.addView(label(title, 14f, 0xFFB9C7D8.toInt()), params(bottom = 2))
            panel.addView(label(value, 17f, color, true), params(bottom = 12))
        }
        row("Date & Time", endTime.ifBlank { now() })
        row("Start Location", startLocation.ifBlank { "Not available" })
        row("End Location", endLocation.ifBlank { "Not available" })
        row("Distance", String.format(Locale.US, "%.2f km", roundedKm()))
        row("Trip Time", if (startTime.isNotBlank()) "$startTime - ${endTime.ifBlank { now() }}" else "Not available")
        row("Fare Amount", String.format(Locale.US, "₹%.2f", fareAmount()), 0xFFFFA51F.toInt())
        root.addView(panel, params(bottom = 16))
        root.addView(styledButton("DOWNLOAD PDF BILL", 0xFFFFA51F.toInt()).apply {
            setTextColor(0xFF101820.toInt()); setOnClickListener { createPdf() }
        }, params(h = 56, bottom = 10))
        root.addView(styledButton("CONTINUE TO PAYMENT", 0xFF0866E8.toInt()).apply {
            setOnClickListener { showPaymentScreen() }
        }, params(h = 56, bottom = 10))
        root.addView(styledButton("BACK TO GPS METER", 0xFF34445B.toInt()).apply {
            setOnClickListener { buildScreen() }
        }, params(h = 48))
        setContentView(root)
    }

    private fun showDashboard() {
        paymentScreen = false
        window.statusBarColor = 0xFF071323.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(0xFF071323.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("RTO METER RATE", 23f, 0xFFFFA51F.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("● READY", 13f, 0xFF65D889.toInt(), true))
        root.addView(header, params(bottom = 18))

        val profile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(0xFF17263A.toInt())
        }
        profile.addView(label(driverName.ifBlank { "Driver Profile" }, 20f, -1, true))
        profile.addView(label(prefs.getString("vehicle_number", "")?.ifBlank { "Add your vehicle number in Profile" } ?: "Add your vehicle number in Profile", 14f, 0xFFCAD5E3.toInt()))
        profile.addView(label("TAP TO VIEW / EDIT PROFILE", 11f, 0xFFFFA51F.toInt(), true))
        profile.setOnClickListener { showDriverProfile() }
        root.addView(profile, params(bottom = 16))

        fun tile(title: String, subtitle: String, color: Int = 0xFFFFA51F.toInt(), action: () -> Unit) {
            val b = styledButton("$title\n$subtitle", 0xFF17263A.toInt()).apply {
                setTextColor(color); textSize = 16f; setOnClickListener { action() }
            }
            root.addView(b, params(h = 68, bottom = 9))
        }
        tile("GPS METER", "Start / Stop trip", action = { buildScreen() })
        tile("TRIP HISTORY", "Previous trips", action = { showHistory() })
        tile("DAILY INCOME", "Income and expenses", action = { showDailyAccounts() })
        tile("PDF BILL", "Create / download bill", action = { createPdf() })
        tile("SOS SAFETY", "Emergency assistance", 0xFFFF6666.toInt(), action = { showDriverSafety() })
        tile("DRIVER PROFILE", "Edit personal and vehicle details", action = { showDriverProfile() })
        tile("SETTINGS", "App settings", action = { showSettings() })
        setContentView(root)
    }

    private fun saveTripAndReturn() {
        val history = prefs.getString("history", "") ?: ""
        val record = "${now()} | ${String.format(Locale.US, "%.2f", roundedKm())} km | ₹${String.format(Locale.US, "%.2f", fareAmount())}"
        prefs.edit().putString("history", if (history.isBlank()) record else "$record\n$history")
            .putFloat("income_total", (prefs.getFloat("income_total", 0f).toDouble() + fareAmount()).toFloat()).commit()
        totalMeters = 0.0; tracking = false; startTime = ""; endTime = ""
        startLocation = ""; endLocation = ""
        prefs.edit().putFloat("total_meters", 0f).putBoolean("tracking", false)
            .putString("start_time", "").putString("end_time", "")
            .putString("start_location", "").putString("end_location", "").commit()
        showDashboard()
        AlertDialog.Builder(this).setTitle("Payment Collected")
            .setMessage("Cash payment has been recorded.")
            .setPositiveButton("OK", null).show()
    }

    private fun prompt(title: String, hint: String, initial: String = "", onSave: (String) -> Unit) {
        val input = EditText(this).apply { setSingleLine(true); this.hint = hint; setText(initial); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("Save") { _, _ -> onSave(input.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showDailyAccounts() {
        val income = prefs.getFloat("income_total", 0f).toDouble()
        val expense = prefs.getFloat("expense_total", 0f).toDouble()
        val msg = "एकूण कमाई: ₹%.2f\\nएकूण खर्च: ₹%.2f\\nनिव्वळ शिल्लक: ₹%.2f".format(income, expense, income-expense)
        AlertDialog.Builder(this).setTitle("Daily Income & Expense").setMessage(msg)
            .setPositiveButton("खर्च जोडा") { _, _ -> prompt("खर्चाची रक्कम (₹)", "उदा. 250") { value ->
                val amount = value.toDoubleOrNull()
                if (amount == null || amount < 0) Toast.makeText(this,"योग्य रक्कम टाका",Toast.LENGTH_SHORT).show()
                else { prefs.edit().putFloat("expense_total", (prefs.getFloat("expense_total",0f)+amount.toFloat())).apply(); showDailyAccounts() }
            } }
            .setNeutralButton("आजचा हिशोब Reset") { _, _ ->
                AlertDialog.Builder(this).setMessage("कमाई व खर्चाचे एकूण आकडे Reset करायचे?").setPositiveButton("Reset") { _, _ -> prefs.edit().putFloat("income_total",0f).putFloat("expense_total",0f).apply(); showDailyAccounts() }.setNegativeButton("Cancel",null).show()
            }.setNegativeButton("बंद",null).show()
    }

    private fun showVehicleReminders() {
        val docs = listOf("Insurance", "PUC", "Fitness Certificate", "Driving Licence", "Permit")
        val saved = docs.map { it to (prefs.getString("expiry_$it", "") ?: "") }
        val lines = saved.joinToString("\\n") { (name,date) -> "$name : ${date.ifBlank { "Date not set" }}" }
        AlertDialog.Builder(this).setTitle("Vehicle Document Reminders").setMessage(lines)
            .setPositiveButton("Expiry Date Set") { _, _ ->
                val options = docs.toTypedArray()
                AlertDialog.Builder(this).setTitle("Document निवडा").setItems(options) { _, which ->
                    val doc=options[which]
                    prompt("$doc expiry date", "YYYY-MM-DD", prefs.getString("expiry_$doc","") ?: "") { date ->
                        prefs.edit().putString("expiry_$doc",date).apply()
                        Toast.makeText(this,"$doc तारीख सेव्ह झाली",Toast.LENGTH_SHORT).show()
                    }
                }.show()
            }
            .setNeutralButton("WhatsApp Contact") { _, _ -> sendDocumentHelpWhatsApp("माझ्या वाहनाच्या कागदपत्राबाबत मदत हवी आहे.") }
            .setNegativeButton("बंद",null).show()
        // Expired documents can be sent to the requested support number with a prefilled message.
        val expired = saved.filter { (_,date) -> date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && date < java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
        if (expired.isNotEmpty()) {
            val doc = expired.first().first
            AlertDialog.Builder(this).setTitle("Document Expired").setMessage("$doc संपले आहे. अपडेट/मदतीसाठी WhatsApp संदेश पाठवायचा?")
                .setPositiveButton("WhatsApp संदेश") { _, _ -> sendDocumentHelpWhatsApp("$doc संपला आहे. कृपया अपडेट करण्यासाठी संपर्क करा.") }
                .setNegativeButton("नंतर",null).show()
        }
    }

    private fun sendDocumentHelpWhatsApp(message: String) {
        try {
            val uri = android.net.Uri.parse("https://wa.me/919710409696?text=" + java.net.URLEncoder.encode(message, "UTF-8"))
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) { Toast.makeText(this,"WhatsApp उघडता आले नाही",Toast.LENGTH_LONG).show() }
    }

    private fun showVehicleManagement() {
        val vehicle = prefs.getString("vehicle_number", "") ?: ""
        val type = prefs.getString("vehicle_type", "") ?: ""
        val fuel = prefs.getString("fuel_type", "") ?: ""
        AlertDialog.Builder(this).setTitle("Vehicle Management")
            .setMessage("Vehicle: ${vehicle.ifBlank { "Not set" }}\\nType: ${type.ifBlank { "Not set" }}\\nFuel: ${fuel.ifBlank { "Not set" }}\\nService KM: ${prefs.getString("service_km", "Not set")}")
            .setPositiveButton("Vehicle Number") { _, _ -> prompt("Vehicle Number", "MH12AB1234", vehicle) { prefs.edit().putString("vehicle_number",it).apply(); showVehicleManagement() } }
            .setNeutralButton("Vehicle / Fuel") { _, _ ->
                val fields = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),0) }
                val t=EditText(this).apply { hint="Vehicle type (Car/Taxi)"; setText(type) }; val f=EditText(this).apply { hint="Fuel (CNG/Petrol/Diesel/EV)"; setText(fuel) }; val k=EditText(this).apply { hint="Next service at KM"; setText(prefs.getString("service_km","") ?: "") }
                fields.addView(t);fields.addView(f);fields.addView(k)
                AlertDialog.Builder(this).setTitle("Vehicle Details").setView(fields).setPositiveButton("Save") { _, _ -> prefs.edit().putString("vehicle_type",t.text.toString()).putString("fuel_type",f.text.toString()).putString("service_km",k.text.toString()).apply() }.setNegativeButton("Cancel",null).show()
            }.setNegativeButton("बंद",null).show()
    }

    private fun showDriverSafety() {
        val contact=prefs.getString("sos_contact","") ?: ""
        AlertDialog.Builder(this).setTitle("Driver Safety / SOS")
            .setMessage("Emergency Contact: ${contact.ifBlank { "Not set" }}\\nSOS दाबल्यावर निवडलेल्या संपर्काला कॉल सुरू होईल.")
            .setPositiveButton("SOS Call") { _, _ ->
                if (contact.isBlank()) prompt("Emergency Contact Number", "मोबाईल नंबर") { prefs.edit().putString("sos_contact",it).apply(); showDriverSafety() }
                else try { startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$contact"))) } catch (_: Exception) { }
            }
            .setNeutralButton("Contact Set") { _, _ -> prompt("Emergency Contact Number", "मोबाईल नंबर",contact) { prefs.edit().putString("sos_contact",it).apply() } }
            .setNegativeButton("बंद",null).show()
    }

    private fun chooseLanguage() {
        val langs=arrayOf("मराठी", "हिंदी", "English")
        AlertDialog.Builder(this).setTitle("App Language").setSingleChoiceItems(langs, prefs.getInt("language_index",0)) { dialog, which ->
            prefs.edit().putInt("language_index",which).apply(); dialog.dismiss()
            Toast.makeText(this,"भाषा निवड सेव्ह झाली. काही स्क्रीनवरील भाषांतर पुढील अपडेटमध्ये पूर्ण होईल.",Toast.LENGTH_LONG).show()
        }.setNegativeButton("Cancel",null).show()
    }

    private fun showHistory() {
        val history = prefs.getString("history", "") ?: ""
        AlertDialog.Builder(this).setTitle("प्रवास नोंदी (History)")
            .setMessage(if (history.isBlank()) "अजून कोणताही पूर्ण प्रवास नाही." else history.replace("\n", "\n"))
            .setPositiveButton("OK", null).show()
    }


    private fun showDriverProfile() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFF071323.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(label("DRIVER PROFILE", 24f, 0xFFFFA51F.toInt(), true), params(bottom = 14))

        val photoUri = prefs.getString("profile_photo_uri", null)
        val photo = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(104), dp(104)).apply { gravity = Gravity.CENTER; bottomMargin = dp(10) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF17263A.toInt())
            if (!photoUri.isNullOrBlank()) {
                try { setImageURI(android.net.Uri.parse(photoUri)) } catch (_: Exception) { }
            }
        }
        content.addView(photo)
        content.addView(styledButton("CHANGE PROFILE PHOTO", 0xFF34445B.toInt()).apply {
            setOnClickListener { profilePhotoPicker.launch("image/*") }
        }, params(h = 48, bottom = 16))

        fun field(title: String, key: String, hintText: String): EditText {
            content.addView(label(title, 13f, 0xFFCAD5E3.toInt(), true), params(bottom = 4))
            val edit = EditText(this).apply {
                setSingleLine(true)
                hint = hintText
                setText(prefs.getString(key, "") ?: "")
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
                setHintTextColor(0xFF9AAABD.toInt())
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(0xFF17263A.toInt())
            }
            content.addView(edit, params(bottom = 12))
            return edit
        }
        val name = field("DRIVER NAME", "driver_name", "Enter driver name")
        val mobile = field("MOBILE NUMBER", "driver_mobile", "Enter mobile number")
        val vehicleNo = field("VEHICLE NUMBER", "vehicle_number", "e.g. MH12AB1234")
        val vehicleType = field("VEHICLE TYPE", "vehicle_type", "Car / Auto / Bike")
        val vehicleModel = field("VEHICLE MODEL", "vehicle_model", "Enter vehicle model")
        val emergency = field("EMERGENCY CONTACT", "emergency_contact", "Enter emergency number")

        content.addView(styledButton("SAVE / UPDATE PROFILE", 0xFF0866E8.toInt()).apply {
            setOnClickListener {
                driverName = name.text.toString().trim()
                prefs.edit()
                    .putString("driver_name", driverName)
                    .putString("driver_mobile", mobile.text.toString().trim())
                    .putString("vehicle_number", vehicleNo.text.toString().trim())
                    .putString("vehicle_type", vehicleType.text.toString().trim())
                    .putString("vehicle_model", vehicleModel.text.toString().trim())
                    .putString("emergency_contact", emergency.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        }, params(h = 56, bottom = 10))
        content.addView(styledButton("BACK TO DASHBOARD", 0xFF34445B.toInt()).apply {
            setOnClickListener { showDashboard() }
        }, params(h = 48))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showSettings() {
        val input = EditText(this).apply {
            setSingleLine(true); setText(driverName); hint = "ड्रायव्हरचे नाव"
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("ड्रायव्हरचे नाव बदला")
            .setMessage("प्रत्येक ड्रायव्हरसाठी नाव येथे Edit करा.")
            .setView(input)
            .setPositiveButton("सेव्ह करा") { _, _ ->
                driverName = input.text.toString().trim()
                prefs.edit().putString("driver_name", driverName).apply()
                buildScreen()
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun editLocation(isStart: Boolean) {
        val input = EditText(this).apply {
            setText(if (isStart) startLocation else endLocation)
            hint = "ठिकाण / पत्ता लिहा"; minLines = 2
        }
        AlertDialog.Builder(this)
            .setTitle(if (isStart) "Start Location बदला" else "End Location बदला")
            .setView(input)
            .setPositiveButton("सेव्ह करा") { _, _ ->
                val value = input.text.toString().trim()
                if (isStart) startLocation = value else endLocation = value
                prefs.edit().putString(if (isStart) "start_location" else "end_location", value).apply()
                buildScreen()
            }
            .setNeutralButton("Automatic GPS") { _, _ -> captureLocation(isStart, true) }
            .setNegativeButton("रद्द", null).show()
    }

    @Suppress("MissingPermission")
    private fun captureLocation(isStart: Boolean, redraw: Boolean = false) {
        if (!hasFineLocationPermission()) return
        val client = LocationServices.getFusedLocationProviderClient(this)
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                if (loc == null) {
                    client.lastLocation.addOnSuccessListener { last ->
                        if (last != null) saveLocationAddress(last, isStart, redraw)
                        else Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
                    }
                } else saveLocationAddress(loc, isStart, redraw)
            }
            .addOnFailureListener {
                Toast.makeText(this, "GPS लोकेशन मिळाली नाही. Manual Edit वापरा.", Toast.LENGTH_LONG).show()
            }
    }

    @Suppress("DEPRECATION")
    private fun saveLocationAddress(location: Location, isStart: Boolean, redraw: Boolean) {
        try {
            val geocoder = Geocoder(this, Locale("mr", "IN"))
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val address = addresses?.firstOrNull()?.getAddressLine(0)
                ?: String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = address else endLocation = address
            prefs.edit().putString(if (isStart) "start_location" else "end_location", address).apply()
        } catch (_: Exception) {
            val coordinates = String.format(Locale.US, "%.5f, %.5f", location.latitude, location.longitude)
            if (isStart) startLocation = coordinates else endLocation = coordinates
            prefs.edit().putString(if (isStart) "start_location" else "end_location", coordinates).apply()
        }
        if (paymentScreen) showPaymentScreen() else if (redraw) buildScreen()
    }

    private fun refreshNumbers() {
        val km = roundedKm()
        if (::distanceText.isInitialized) distanceText.text = String.format(Locale.US, "%.2f km", km)
        if (::fareText.isInitialized) fareText.text = String.format(Locale.US, "₹%.2f", fareAmount())
        if (::startButton.isInitialized) {
            startButton.isEnabled = !tracking
            startButton.alpha = if (tracking) .45f else 1f
            endButton.isEnabled = tracking
            endButton.alpha = if (tracking) 1f else .45f
            if (::pdfButton.isInitialized) {
                pdfButton.isEnabled = !tracking && endTime.isNotBlank()
                pdfButton.alpha = if (pdfButton.isEnabled) 1f else .55f
            }
        }
    }

    private fun now() = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale("en", "IN")).format(Date())

    private fun createPdf() {
        if (endTime.isBlank()) {
            Toast.makeText(this, "प्रवास संपल्यानंतर PDF बिल डाउनलोड करा.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "RTO_METER_RATE_Bill_${System.currentTimeMillis()}.pdf")
        }
        startActivityForResult(intent, createPdfCode)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createPdfCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { writePdf(it) }
                Toast.makeText(this, "PDF बिल सेव झाले.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "PDF सेव करताना त्रुटी: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writePdf(out: OutputStream) {
        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 20f }
        paint.textSize = 28f; paint.isFakeBoldText = true; canvas.drawText("RTO METER RATE", 50f, 70f, paint)
        paint.textSize = 16f; paint.isFakeBoldText = false; canvas.drawText("GPS TRIP BILL", 50f, 105f, paint)
        canvas.drawLine(50f, 125f, 545f, 125f, paint)
        paint.textSize = 18f
        val lines = listOf(
            "Driver: $driverName", "Trip date: $startTime", "Trip ended: $endTime",
            "Start location: ${startLocation.ifBlank { "Not available" }}",
            "End location: ${endLocation.ifBlank { "Not available" }}",
            String.format(Locale.US, "Distance: %.2f km", roundedKm()),
            "Rate: Rs. 25.00 per km",
            String.format(Locale.US, "TOTAL FARE: Rs. %.2f", fareAmount())
        )
        var y = 180f
        for (line in lines) {
            var remaining = line
            while (remaining.isNotEmpty()) {
                val count = paint.breakText(remaining, true, 490f, null)
                if (count <= 0) break
                canvas.drawText(remaining.substring(0, count), 50f, y, paint)
                remaining = remaining.substring(count).trimStart()
                y += 28f
            }
            y += 14f
        }
        paint.textSize = 12f
        canvas.drawText("Distance is calculated using device GPS. Actual accuracy may vary.", 50f, minOf(y + 20f, 800f), paint)
        pdf.finishPage(page); pdf.writeTo(out); pdf.close()
    }
}
