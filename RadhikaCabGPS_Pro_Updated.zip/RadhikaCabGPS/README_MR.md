# Radhika Cab GPS Fare Meter – Updated

- भाडे दर: ₹25 प्रति km
- START / END प्रवास नियंत्रण
- GPS Foreground Service द्वारे Background tracking
- पेमेंट स्क्रीन: PAY IN CASH
- PDF बिल डाउनलोड
- CASH COLLECTED नंतर धन्यवाद संदेश व मुख्य स्क्रीन
- प्रवास History व Settings

## Build
Android project root मधून `gradle clean assembleDebug` चालवा.
APK: `app/build/outputs/apk/debug/app-debug.apk`

## महत्त्वाच्या सूचना
- पहिल्यांदा वापरताना Precise Location आणि Notifications परवानगी द्या.
- Android Settings मध्ये Radhika Cab साठी Battery usage `Unrestricted`/`Allow background activity` उपलब्ध असल्यास निवडा.
- GPS अंतराची अचूकता फोन, सिग्नल आणि GPS परिस्थितीवर अवलंबून असते. प्रत्यक्ष प्रवासात भाडे तपासूनच वापरा.
- या आवृत्तीत नकाशा पॅनल हे GPS स्थिती दाखवणारे डिझाइन पॅनल आहे; Google Maps नकाशा API जोडलेला नाही.
